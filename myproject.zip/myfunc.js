let i = 0;
setInterval(myfunc,1000);
function myfunc()
 {
    i++;
    console.log(i);
  }